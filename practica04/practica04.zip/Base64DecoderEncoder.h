#ifndef BASE64_DE_H
#define BASE64_DE_H

#include <iostream>
using namespace std;

// Declaración de funciones
void preCalcBase64();
string base64Encode(string input);
string base64Decode(string input); 

#endif // BASE64_DE_H